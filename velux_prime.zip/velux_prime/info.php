<?php

$info['name'] = 'Velux Prime';
$info['description'] = 'Dark Gaming Theme';
$info['version'] = '1.x';
$info['author'] = "ALCHEM;";
$info['author_url'] = 'http://mixzone.ro';
$info['license'] = 'Core License';
$info['core'] = '1.x';
$info['parent_theme'] = 'default';